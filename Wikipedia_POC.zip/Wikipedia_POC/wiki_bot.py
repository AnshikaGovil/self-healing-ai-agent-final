"""Wikipedia POC, offline healing: a bot built for the 2010 design, run on 2022's.

Wikipedia still serves both of its desktop designs, live, at one address:

    old  Vector legacy (2010)  ?useskin=vector
    new  Vector 2022           ?useskin=vector-2022   (the default since 2023)

The article is identical; the page around it was rebuilt - exactly what a
vendor release does to an RPA bot. Every selector in LOCATORS was written
against the old design. On the new one three of them break.

This version heals with NO healing service and NO API call. Everything it
knows is in memory/offline_memory.json, on this machine:

* the learning run (--design old) fingerprints every element the bot uses
  while the 2010 selectors still work;
* a broken step is re-identified in the live page from that fingerprint -
  same words, same label, same destination, same form - and the repair is
  written back to memory;
* the next run recalls that repair straight from memory.

    python wiki_bot.py --design old            # before the release: learn
    python wiki_bot.py --design new --plain    # after it, healing OFF
    python wiki_bot.py --design new            # after it, healing ON
    python wiki_bot.py --design new            # again: healed from memory

wiki_bot_service.py is the same POC healing through the healing service.
"""

from __future__ import annotations

import argparse
import json
import os
import re
import sys
import time

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

from selenium import webdriver                                  # noqa: E402
from selenium.common.exceptions import (                        # noqa: E402
    StaleElementReferenceException, WebDriverException)
from selenium.webdriver.chrome.options import Options           # noqa: E402
from selenium.webdriver.common.by import By                     # noqa: E402

from cards import Cards                                         # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))
MEMORY_FILE = os.path.join(HERE, "memory", "offline_memory.json")
WIKI = "https://en.wikipedia.org/wiki/%s?useskin=%s"
DESIGNS = {
    "old": ("vector", "2010 design", "Vector legacy, 2010"),
    "new": ("vector-2022", "2022 redesign", "Vector 2022, live since 2023"),
}

# Written against the 2010 design. The description is what the room reads.
LOCATORS = {
    "article.title": ("#firstHeading", "the article title"),
    "article.headings": ("#mw-content-text .mw-heading2 h2",
                         "the section headings"),
    "article.edited": ("#footer-info-lastmod",
                       "the 'last edited' line"),
    "account.login": ("#pt-login a", "the Log in link"),
    "search.box": ("input.vector-search-box-input", "the search box"),
    "search.button": ("#searchButton", "the search button"),
}

# (label, locator, kind, what the step does, in business words)
STEPS = [
    ("Article title", "article.title", "read", "Read the article title"),
    ("Section headings", "article.headings", "collect",
     "Collect every section heading"),
    ("Last edited", "article.edited", "read",
     "Note when the page was last edited"),
    ("Log in link", "account.login", "read", "Check the Log in link"),
    ("Search box", "search.box", "type", "Type the next topic to research"),
    ("Search button", "search.button", "click", "Run the search"),
    ("Result page", "article.title", "verify",
     "Confirm the search landed on the right article"),
]

WAIT_S = 3.0     # how long either arm waits for an element before giving up


# ------------------------------------------------------------------ memory
FINGERPRINT_JS = r"""
const el = arguments[0];
const clean = s => (s || '').split('[alt-')[0].replace(/\s+/g, ' ').trim().toLowerCase();
let href = el.getAttribute('href') || '';
if (href) { try { const u = new URL(href, location.href);
  href = u.pathname + '?title=' + (u.searchParams.get('title') || ''); } catch (e) {} }
const form = el.closest('form');
const p = el.parentElement;
return {tag: el.tagName.toLowerCase(), id: el.id || '',
  type: (el.getAttribute('type') || '').toLowerCase(),
  name: el.getAttribute('name') || '', aria: clean(el.getAttribute('aria-label')),
  placeholder: clean(el.getAttribute('placeholder')),
  title: clean(el.getAttribute('title')),
  text: clean(el.innerText || (el.tagName === 'INPUT' ? el.value : '') || ''),
  href: href, accesskey: el.getAttribute('accesskey') || '',
  form: form ? (form.id || '') : '', parentId: (p && p.id) || ''};
"""

# Re-identify a fingerprinted element in the live page, all in the browser:
# no service, no model, no network. Returns the element, a selector that
# matches it alone among visible elements, and how many were compared.
MATCH_JS = (r"""
const f = arguments[0], preferId = arguments[1];
const fpOf = function () { %FP% };
const vis = e => { if (e.closest('#bisxRoot')) { return false; }
  const r = e.getBoundingClientRect(); const cs = getComputedStyle(e);
  return r.width > 0 && r.height > 0 && cs.visibility !== 'hidden' && cs.display !== 'none'; };
const fam = g => {
  if (g.tag === 'a') { return 'link'; }
  if (g.tag === 'button' || (g.tag === 'input' &&
      ['submit', 'button', 'image', 'reset'].includes(g.type))) { return 'button'; }
  if (g.tag === 'input' || g.tag === 'textarea') { return 'field'; }
  return g.tag; };
const base = s => (s || '').replace(/[-_]?\d+$/, '');
const want = fam(f);
const pool = [...document.querySelectorAll('a,button,input,textarea,select,[role=button]')].filter(vis);
let best = null, second = 0;
for (const e of pool) {
  const g = fpOf(e);
  if (fam(g) !== want) { continue; }
  let s = 0;
  if (f.text && g.text === f.text) { s += 3; }
  if (f.aria && g.aria === f.aria) { s += 3; }
  if (f.placeholder && g.placeholder === f.placeholder) { s += 2; }
  if (f.name && g.name === f.name) { s += 2; }
  if (f.title && g.title === f.title) { s += 1.5; }
  if (f.href && g.href === f.href) { s += 3; }
  if (f.accesskey && g.accesskey === f.accesskey) { s += 1; }
  if (f.form && g.form === f.form) { s += 2; }
  if (f.id && g.id && base(f.id) === base(g.id)) { s += 2; }
  if (f.parentId && g.parentId && base(f.parentId) === base(g.parentId)) { s += 2; }
  if (f.type === 'submit' && g.tag === 'button' && (g.type === '' || g.type === 'submit')) { s += 1; }
  if (g.tag === f.tag) { s += 0.5; }
  if (!best || s > best.s) { if (best) { second = Math.max(second, best.s); } best = {e: e, s: s}; }
  else { second = Math.max(second, s); }
}
// Too little in common, or a tie: refuse rather than guess.
if (!best || best.s < 2.5 || best.s - second < 1) { return null; }
const el = best.e, tag = el.tagName.toLowerCase();
const uniq = sel => { try { const m = [...document.querySelectorAll(sel)].filter(vis);
  return m.length === 1 && m[0] === el; } catch (e) { return false; } };
const q = v => v.replace(/"/g, '');
const opts = [];
const pid = el.parentElement && el.parentElement.id;
const form = el.closest('form');
if (preferId && el.id) { opts.push('#' + CSS.escape(el.id)); }
if (preferId && pid) { opts.push('#' + CSS.escape(pid) + ' ' + tag); }
if (el.getAttribute('aria-label')) { opts.push(tag + '[aria-label="' + q(el.getAttribute('aria-label')) + '"]'); }
if (el.getAttribute('name')) { opts.push(tag + '[name="' + q(el.getAttribute('name')) + '"]'); }
if (el.id) { opts.push('#' + CSS.escape(el.id)); }
if (pid) { opts.push('#' + CSS.escape(pid) + ' ' + tag); }
if (form && form.id) {
  if (el.classList[0]) { opts.push('#' + CSS.escape(form.id) + ' ' + tag + '.' + CSS.escape(el.classList[0])); }
  opts.push('#' + CSS.escape(form.id) + ' ' + tag); }
const sel = opts.find(uniq) || '';
return sel ? {el: el, selector: sel, compared: pool.length} : null;
""").replace("%FP%", FINGERPRINT_JS)


def load_memory():
    try:
        with open(MEMORY_FILE, encoding="utf-8") as handle:
            mem = json.load(handle)
    except (OSError, ValueError):
        mem = {}
    mem.setdefault("fingerprints", {})
    mem.setdefault("repairs", {})
    return mem


def save_memory(mem):
    os.makedirs(os.path.dirname(MEMORY_FILE), exist_ok=True)
    tmp = MEMORY_FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as handle:
        json.dump(mem, handle, indent=2)
    os.replace(tmp, MEMORY_FILE)


# ------------------------------------------------------------------ output
class Paint(object):
    """ANSI colour when the console can show it, plain text when it cannot."""

    def __init__(self):
        self.on = sys.stdout.isatty()
        if self.on and os.name == "nt":
            os.system("")               # switches on VT processing in conhost

    def __call__(self, text, code):
        return "\033[%sm%s\033[0m" % (code, text) if self.on else text

    def ok(self, t):
        return self(t, "1;34")

    def healed(self, t):
        return self(t, "1;32")

    def bad(self, t):
        return self(t, "1;31")

    def warn(self, t):
        return self(t, "1;33")

    def dim(self, t):
        return self(t, "2")

    def bold(self, t):
        return self(t, "1")


P = Paint()


def clip(text, n):
    text = " ".join(str(text).split())
    return text if len(text) <= n else text[:n - 3] + "..."


def banner(lines, paint):
    width = max(len(l) for l in lines) + 4
    print("  " + paint("+" + "-" * width + "+"))
    for l in lines:
        print("  " + paint("|  " + l.ljust(width - 4) + "  |"))
    print("  " + paint("+" + "-" * width + "+"))


# ------------------------------------------------------------------ browser
def open_browser(headless):
    opts = Options()
    if headless:
        opts.add_argument("--headless=new")
        opts.add_argument("--window-size=1600,900")
    else:
        opts.add_argument("--start-maximized")
    opts.add_argument("--log-level=3")
    opts.add_experimental_option("excludeSwitches",
                                 ["enable-logging", "enable-automation"])
    return webdriver.Chrome(options=opts)


def highlight(driver, els, colour):
    """Ring what the step is using, so the room can follow the bot."""
    try:
        driver.execute_script(
            "const els = arguments[0];"
            "for (const e of els) {"
            "  e.style.outline = '4px solid ' + arguments[1];"
            "  e.style.outlineOffset = '3px'; e.style.borderRadius = '4px'; }"
            "if (els[0]) els[0].scrollIntoView({block: 'center',"
            " behavior: 'smooth'});",
            els[:30], colour)
    except WebDriverException:
        pass


def to_top(driver):
    try:
        driver.execute_script("window.scrollTo({top: 0, behavior: 'smooth'});")
    except WebDriverException:
        pass


def wait_for_new_page(driver, old_url, timeout=20):
    end = time.time() + timeout
    while time.time() < end:
        try:
            if (driver.current_url != old_url and driver.execute_script(
                    "return document.readyState") == "complete"):
                return True
        except WebDriverException:
            pass
        time.sleep(0.25)
    return False


def plain_lookup(driver, selector, many, timeout=WAIT_S):
    """The bot as it was written: plain Selenium, waiting for a visible match."""
    end = time.time() + timeout
    while True:
        try:
            shown = [e for e in driver.find_elements(By.CSS_SELECTOR, selector)
                     if e.is_displayed()]
        except WebDriverException:
            shown = []
        if shown:
            return shown if many else shown[:1]
        if time.time() >= end:
            raise LookupError("no visible element matches %s" % selector)
        time.sleep(0.25)


def heal(driver, key, mem):
    """Find a broken step's element from memory alone. (element, how, sel)."""
    selector = LOCATORS[key][0]
    repair = mem["repairs"].get(key)
    if repair and repair.get("from") == selector:
        try:
            hit = [e for e in driver.find_elements(By.CSS_SELECTOR,
                                                   repair["to"])
                   if e.is_displayed()]
        except WebDriverException:
            hit = []
        if hit:
            return hit[0], "memory", repair["to"]
    fp = mem["fingerprints"].get(key)
    if not fp:
        return None, "unlearned", ""
    found = driver.execute_script(MATCH_JS, fp, "#" in selector)
    if not found:
        return None, "refused", ""
    mem["repairs"][key] = {"from": selector, "to": found["selector"],
                           "learned": time.strftime("%Y-%m-%d %H:%M")}
    save_memory(mem)
    return found["el"], "fingerprint", found["selector"]


def refind(driver, selector, fallback):
    """The first visible match of selector now, or fallback if none."""
    end = time.time() + 3
    while time.time() < end:
        try:
            for e in driver.find_elements(By.CSS_SELECTOR, selector):
                if e.is_displayed():
                    return e
        except WebDriverException:
            pass
        time.sleep(0.2)
    if fallback is None:
        raise LookupError("%s is no longer on the page" % selector)
    return fallback


def section_names(els):
    out = []
    for e in els:
        text = re.sub(r"^\d+(\.\d+)*\s*", "", " ".join(e.text.split()))
        if text and text not in ("(Top)", "Contents"):
            out.append(text)
    return out


# ------------------------------------------------------------------ the run
def run(driver, cards, args, mem, rows, data):
    """Run the job. Returns the row that failed, or None."""
    learning = args.design == "old"
    healing = not args.plain and not learning
    pace = args.pace
    total = len(STEPS)
    for n, (label, key, kind, doing) in enumerate(STEPS, 1):
        i = n - 1
        selector, describe = LOCATORS[key]
        row = {"n": n, "label": label, "selector": selector, "value": "",
               "error": "", "heal": None}
        rows.append(row)
        kicker = "Step %d of %d" % (n, total)
        cards.step(i, "run", "working")
        cards.show("run", kicker, doing,
                   "Looking for %s with the address written for the 2010 "
                   "design." % describe, old_sel=selector,
                   old_label="Address")
        time.sleep(pace * 0.6)
        try:
            try:
                els = plain_lookup(driver, selector, kind == "collect")
            except LookupError:
                if not healing:
                    raise
                cards.step(i, "run", "broken")
                cards.show("broken", kicker + "  -  broken by the release",
                           "The old address finds nothing",
                           "The 2022 redesign changed %s. Without healing, "
                           "the bot would stop right here." % describe,
                           old_sel=selector)
                time.sleep(pace * 1.1)
                cards.show("healing", kicker + "  -  self-healing",
                           "Healing %s ..." % describe,
                           "Recalling it from memory and matching its 2010 "
                           "fingerprint against the live page, offline.",
                           old_sel=selector)
                time.sleep(pace * 0.7)
                t0 = time.perf_counter()
                el, how, new_sel = heal(driver, key, mem)
                heal_s = time.perf_counter() - t0
                if el is None:
                    raise LookupError({
                        "unlearned": "nothing learned for this step - run "
                                     "--design old first",
                        "refused": "no safe match - refused, not guessed",
                    }.get(how, "not found"))
                els = [el]
                row["heal"] = {"how": how, "to": new_sel, "secs": heal_s}

            highlight(driver, els, "#10B981" if row["heal"] else "#3B82F6")
            time.sleep(0.4)

            if kind == "read":
                value = " ".join(els[0].text.split())
                if not value:
                    raise LookupError("the element has no text")
            elif kind == "collect":
                names = section_names(els)
                if len(names) < 3:
                    raise LookupError("only %d section names" % len(names))
                data["sections"] = names
                value = "%d sections: %s" % (len(names), ", ".join(names[:3]))
            elif kind == "type":
                # The 2022 search box is replaced by Wikipedia's own script
                # the moment it takes focus, so focus it, then find it again
                # by the address that worked before typing into it.
                use = row["heal"]["to"] if row["heal"] else selector
                for attempt in range(3):
                    try:
                        els[0].click()
                        time.sleep(0.8)
                        els = [refind(driver, use, els[0])]
                        els[0].clear()
                        for ch in args.query:
                            els[0].send_keys(ch)
                            time.sleep(0.07)
                        break
                    except StaleElementReferenceException:
                        if attempt == 2:
                            raise
                        els = [refind(driver, use, els[0])]
                value = 'typed "%s"' % args.query
            elif kind == "click":
                value = "search submitted"
            else:
                value = " ".join(els[0].text.split())
                if value.lower() != args.query.lower():
                    raise LookupError('landed on "%s"' % value)
            row["value"] = value
            data[label] = value

            if learning:
                mem["fingerprints"][key] = driver.execute_script(
                    "return (function () {" + FINGERPRINT_JS + "})"
                    ".apply(null, arguments);", els[0])
                save_memory(mem)

            h = row["heal"]
            if h:
                cards.step(i, "healed", "healed in %.2f s" % h["secs"])
                cards.show(
                    "healed", kicker + "  -  healed",
                    "%s found again" % describe[0].upper() + describe[1:],
                    ("Recalled straight from memory - this repair was "
                     "learned on an earlier run." if h["how"] == "memory"
                     else "Found again on the redesigned page and saved "
                          "to memory for every run after this one."),
                    old_sel=selector, new_sel=h["to"],
                    stats=[("Healing time", "%.2f s" % h["secs"], "bisxG")])
                time.sleep(pace * 1.6)
            elif learning:
                cards.step(i, "learned", "learned")
                cards.show("learned", kicker + "  -  learned",
                           doing + " - done",
                           "Works on the 2010 design. Its fingerprint is now "
                           "in memory: %s" % clip(value, 70),
                           old_sel=selector, old_label="Address")
                time.sleep(pace)
            else:
                cards.step(i, "ok", "ok")
                cards.show("ok", kicker + "  -  OK", doing + " - done",
                           clip(value, 90), old_sel=selector,
                           old_label="Address")
                time.sleep(pace * 0.8)

            if kind == "click":
                before = driver.current_url
                use = row["heal"]["to"] if row["heal"] else selector
                try:
                    els[0].click()
                except StaleElementReferenceException:
                    refind(driver, use, None).click()
                if not wait_for_new_page(driver, before):
                    raise LookupError("the click did not open a new page")
                time.sleep(1.0)
                cards.draw()
            else:
                to_top(driver)
        except Exception as exc:
            row["error"] = str(exc).split("\n")[0]
            if row["error"].startswith("Message:"):
                row["error"] = "the browser refused the step"
            cards.step(i, "failed", "failed")
            for j in range(n, total):
                cards.steps[j]["state"] = "skip"
            cards.show("failed", kicker + "  -  BOT STOPPED",
                       "The bot cannot continue",
                       ("The 2022 redesign changed %s, and the script only "
                        "knows the 2010 address. Today an engineer has to "
                        "fix the script before it runs again." % describe)
                       if args.plain else row["error"],
                       old_sel=selector,
                       stats=[("Steps done", "%d / %d" % (n - 1, total),
                               "bisxR"),
                              ("Healing Agent", "OFF" if args.plain else "ON",
                               "")])
            print_row(row)
            return row
        print_row(row)
    return None


ROW = "  %-2s %-17s %-31s "


def print_row(r):
    head = ROW % (r["n"], r["label"], clip(r["selector"], 31))
    if r["error"]:
        print(head + P.bad("FAILED ") + " " + clip(r["error"], 60))
    elif r["heal"]:
        h = r["heal"]
        print(head + P.healed("HEALED ") + " " + clip(r["value"], 44))
        print(" " * len(head) + P.healed("        -> %s" % h["to"]))
        print(" " * len(head) + P.dim("           healed in %.2f s from %s, "
                                      "no API call" % (
                                          h["secs"], "memory"
                                          if h["how"] == "memory"
                                          else "its 2010 fingerprint")))
    else:
        print(head + P.ok("OK     ") + " " + clip(r["value"], 44))


def main():
    ap = argparse.ArgumentParser(
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--design", choices=sorted(DESIGNS), default="new",
                    help="old = before the release (2010 design, learns), "
                         "new = after it (2022 redesign)")
    ap.add_argument("--plain", action="store_true",
                    help="healing OFF - plain Selenium, the control run")
    ap.add_argument("--article", default="Robotic_process_automation")
    ap.add_argument("--query", default="Machine learning")
    ap.add_argument("--pace", type=float, default=2.2,
                    help="seconds each message card stays up (default "
                         "%(default)s; 1 is brisk, 3 is very slow)")
    ap.add_argument("--forget-repairs", action="store_true",
                    help="clear the learned repairs (keep the fingerprints), "
                         "so the next healing run re-identifies every step")
    ap.add_argument("--headless", action="store_true")
    args = ap.parse_args()

    mem = load_memory()
    if args.forget_repairs:
        mem["repairs"] = {}
        save_memory(mem)
        print(P.ok("\n  Repairs forgotten; %d fingerprints kept.\n"
                   % len(mem["fingerprints"])))
        return 0

    learning = args.design == "old"
    healing = not args.plain and not learning
    skin, short, long_name = DESIGNS[args.design]
    url = WIKI % (args.article, skin)
    if learning:
        phase, pill, pill_class = ("BEFORE THE RELEASE", "LEARNING",
                                   "bisxLearn")
        mem = {"fingerprints": {}, "repairs": {},
               "learned_on": time.strftime("%Y-%m-%d %H:%M")}
    else:
        phase = "AFTER THE RELEASE"
        pill, pill_class = (("HEALING AGENT ON", "bisxOn") if healing
                            else ("HEALING AGENT OFF", "bisxOff"))
        if healing and not mem["fingerprints"]:
            print(P.bad("\n  Nothing learned yet - run "
                        "'python wiki_bot.py --design old' first.\n"))
            return 2

    print()
    banner(["WIKIPEDIA SELF-HEALING POC   -   Bot Immune System",
            "",
            "Website version : Wikipedia %s (%s)" % (short, long_name),
            "Stage           : %s" % phase.title(),
            "Self-healing    : %s" % ("learning - fingerprints every element"
                                      if learning else
                                      "ON  - offline, healed from memory"
                                      if healing else
                                      "OFF - plain Selenium"),
            "Memory          : %d fingerprints, %d repairs, no API calls" % (
                len(mem["fingerprints"]), len(mem["repairs"]))],
           P.healed if healing else P.bad if args.plain else P.ok)
    print()

    driver = open_browser(args.headless)
    facts = [("Website version", "Wikipedia " + short),
             ("Stage", phase.title())]
    cards = Cards(driver, "Self-healing RPA  |  offline, from memory",
                  pill, pill_class, facts, [s[0] for s in STEPS],
                  "The bot's job  -  %d steps" % len(STEPS))
    rows, data = [], {}
    started = time.time()
    failed = None
    try:
        driver.get(url)
        time.sleep(1.0)
        cards.show("info", phase, "Wikipedia %s" % short,
                   ("The bot runs on the design it was written for, and "
                    "fingerprints every element it uses into memory.")
                   if learning else
                   ("Same bot, same article - but Wikipedia was redesigned. "
                    "Healing Agent %s." % ("ON: broken steps are repaired from "
                                        "memory, offline" if healing
                                        else "OFF: plain Selenium")),
                   stats=[("Steps", str(len(STEPS)), ""),
                          ("Memory", "%d learned" % len(mem["fingerprints"]),
                           "")])
        time.sleep(args.pace * 1.8)
        print(P.dim(ROW % ("#", "step", "address written for 2010")
                    + "result"))
        failed = run(driver, cards, args, mem, rows, data)

        healed = [r for r in rows if r["heal"]]
        heal_total = sum(r["heal"]["secs"] for r in healed)
        if not failed:
            if learning:
                cards.show("done", "Learning complete",
                           "%d of %d steps work on the 2010 design"
                           % (len(rows), len(STEPS)),
                           "Every element is fingerprinted in local memory. "
                           "Now Wikipedia ships its redesign ...",
                           stats=[("Steps passed", "%d / %d" % (
                               len(rows), len(STEPS)), "bisxG"),
                                  ("Learned", str(len(mem["fingerprints"])),
                                   "")])
            elif healed:
                cards.show("done", "Run complete  -  Healing Agent ON",
                           "%d of %d steps passed on the 2022 redesign"
                           % (len(rows), len(STEPS)),
                           "%d broken steps repaired automatically, offline, "
                           "with no human involved." % len(healed),
                           stats=[("Steps passed", "%d / %d" % (
                               len(rows), len(STEPS)), "bisxG"),
                                  ("Healed", str(len(healed)), "bisxG"),
                                  ("Healing time", "%.2f s" % heal_total,
                                   "bisxG")])
            else:
                cards.show("done", "Run complete",
                           "%d of %d steps passed" % (len(rows), len(STEPS)),
                           "Nothing needed repairing.",
                           stats=[("Steps passed", "%d / %d" % (
                               len(rows), len(STEPS)), "bisxG")])
        time.sleep(max(args.pace * 3, 5))
    finally:
        try:
            driver.quit()
        except Exception:
            pass

    total = time.time() - started
    print()
    if failed:
        print(P.bad("  BOT STOPPED at step %d (%s): %s" % (
            failed["n"], failed["label"], failed["error"])))
        if args.plain:
            print(P.dim("  This is today: one changed element stops the run "
                        "until an engineer fixes the script."))
        return 1
    if "sections" in data:
        print(P.dim("  captured: %s - %d sections: %s ..." % (
            data.get("Article title", ""), len(data["sections"]),
            ", ".join(data["sections"][:4]))))
    healed = [r for r in rows if r["heal"]]
    if learning:
        print(P.ok("  LEARNED: %d of %d steps work on the 2010 design; %d "
                   "fingerprints saved to memory/offline_memory.json."
                   % (len(rows), len(STEPS), len(mem["fingerprints"]))))
    elif healed:
        print(P.healed("  PASSED: %d of %d steps on the 2022 redesign - %d "
                       "healed automatically in %.2f s total, offline, "
                       "0 API calls." % (
                           len(rows), len(STEPS), len(healed),
                           sum(r["heal"]["secs"] for r in healed))))
    else:
        print(P.ok("  PASSED: %d of %d steps, nothing needed repairing."
                   % (len(rows), len(STEPS))))
    print(P.dim("  total run time %.1f s" % total))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
