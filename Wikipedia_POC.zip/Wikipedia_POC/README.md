# Wikipedia POC - self-healing, offline, from memory

A bot written for **Wikipedia's 2010 design** runs on **Wikipedia's 2022
redesign**. Wikipedia still serves both, live, at the same address, so this
is a real vendor release on a real website anyone in the room can open.

**No healing service and no API call.** Everything the bot knows is in
`memory/offline_memory.json` on this machine. It learns there on the 2010
design, and on the 2022 design it re-identifies each broken element from what
it learned, in the browser, in about a hundredth of a second. The only
network traffic is Chrome loading Wikipedia.

Chrome opens maximised. See-through message cards at the bottom right narrate each
step for the audience:

* the **website version** (2010 design / 2022 redesign) and the stage
  (before / after the release);
* **HEALING ON** or **HEALING OFF** on every after-release card;
* for each repair: the old address struck through, the new one, the
  **healing time**, and where it was healed from (fingerprint or memory).
  Confidence is not shown.

Each element the bot uses gets a ring: blue when the old address worked,
green when it was healed.

| step | address written for 2010 | on the 2022 design | healed to |
| --- | --- | --- | --- |
| Log in link | `#pt-login a` | still in the page, hidden in a menu | `#pt-login-2 a` |
| Search box | `input.vector-search-box-input` | class removed | `input[aria-label="Search Wikipedia"]` |
| Search button | `#searchButton` | replaced by a new component | `#searchform button.cdx-button` |

Title, section headings, last-edited date and the search result keep
working addresses, so they pass untouched.

---

## Run the demo

Open PowerShell:

```powershell
cd "E:\Bot Immune System\Wikipedia_POC"
```

**Step 1 - before the release: learn on the 2010 design** (about 1 min)

```powershell
python wiki_bot.py --design old
```

Purple **LEARNING** cards; all 7 steps pass and each element is
fingerprinted into memory. Say: *"This is the bot as it runs today, on the
design it was written for. It remembers every element it touches."*

**Step 2 - after the release, healing OFF** (about 40 s)

```powershell
python wiki_bot.py --design new --plain
```

Red **HEALING OFF** pill. Steps 1-3 pass, then step 4 shows **BOT
STOPPED**. Say: *"Same bot, same article, Wikipedia's new design. One moved
link and the run is dead until an engineer fixes the script."*

**Step 3 - after the release, healing ON** (about 1.5 min)

```powershell
python wiki_bot.py --design new
```

Green **HEALING ON** pill. Each broken step shows three cards: **broken by
the release** (red), **self-healing** (amber spinner), **healed** (green)
with the old and new address and the healing time. Ends with **7 of 7 steps
passed, 3 healed**. Say: *"It found each element again from what it
remembered - the same words, label, destination and form - offline, with no
API call, and saved every repair."*

**Step 4 - the same command again** (about 1.5 min)

```powershell
python wiki_bot.py --design new
```

The healed cards now say **Healed from: Memory**. Say: *"The first run paid
for the repair; every run after it recalls it."*

### Before the next audience

Running step 1 again starts a clean memory. To keep what was learned and only
make step 3 heal from the fingerprint again:

```powershell
python wiki_bot.py --forget-repairs
```

### Speed

`--pace` sets how long each card stays up: default `2.2` seconds, `3` for a
very slow walkthrough, `1` for a quick rehearsal. Example:

```powershell
python wiki_bot.py --design new --pace 3
```

## Options

| option | default | what it does |
| --- | --- | --- |
| `--design old` / `new` | `new` | before the release (learns) / after it |
| `--plain` | off | healing OFF - plain Selenium, the control run |
| `--pace SECONDS` | `2.2` | how long each message card stays up |
| `--forget-repairs` | - | clear learned repairs, keep the fingerprints, then exit |
| `--article NAME` | `Robotic_process_automation` | keep the default for the demo |
| `--query TEXT` | `Machine learning` | what the bot searches for |
| `--headless` | off | no browser window (rehearsal only) |

## If something goes wrong

| what you see | do this |
| --- | --- |
| `Nothing learned yet` | run step 1 first |
| `no safe match - refused, not guessed` | the bot would not guess; run step 1 again, then step 3 |
| Chrome does not open, or the page is blank | check the internet connection - Wikipedia itself is live |
| the cards cover too much on a small screen | zoom the browser out (Ctrl and -) before the run gets to step 4 |

Requirements: Python 3.9+, Google Chrome, `pip install selenium`.

The earlier version, which healed through the public healing service and its
cloud AI, is kept as `wiki_bot_service.py` with its runbook in
`README_service.md`.
